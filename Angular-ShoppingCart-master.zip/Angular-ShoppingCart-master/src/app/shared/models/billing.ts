export class Billing {
  $key: string;
  firstName: string;
  lastName: string;
  emailId: string;
  address1: string;
  address2: string;
  country: string;
  state: string;
  zip: string;
}
